// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(RcppNumerical)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <math.h>  
#include <RcppNumerical.h>
#include <cmath>
#include <iostream>
#include <boost/math/common_factor.hpp> 
#include <boost/math/special_functions/bessel.hpp>
#include <boost/math/special_functions/digamma.hpp>

using namespace Numer;
using namespace std;
using namespace arma;
using namespace Rcpp;


// [[Rcpp::export]]
Rcpp::List fVBmlr(arma::mat D, 
                  arma::mat X,
                  Rcpp::List hyper, 
                  int maxIter = 500, 
                  double Tol_ELBO = 1e-2, 
                  double Tol_Par = 1e-2, 
                  int Trace = 0) {
  
  Rcpp::List out;
  /* Get dimensions */
  double d = D.n_rows;
  double n = D.n_cols-1;
  double d_ = X.n_rows;
  
  /* Non sparse prior */
  
  /* Get Hyperparameters */
  double a_nu = hyper["a_nu"]; 
  double b_nu = hyper["b_nu"]; 
  
  double tau = hyper["tau"];
  double ups = hyper["ups"]; 
  
  /* Initialize */
  arma::cube Sigma_q_phi = zeros(d_,d_,d);
  for (int i = 0; i < d; i++) {
    Sigma_q_phi.slice(i) = eye(d_,d_);
  }
  arma::mat Mu_q_phi = zeros(d,d_);
  
  arma::mat Mu_q_beta = zeros(d,d);
  arma::cube Sigma_q_beta = zeros(d,d,d);
  arma::mat Omega_hat = eye(d,d);
  
  arma::vec mu_q_nu = ones(d);
  arma::vec a_q_nu = (n/2+a_nu)*ones(d);
  arma::vec b_q_nu = ones(d);
  
  /* Get useful quantities */
  arma::mat Y = D.cols(1,n);
  arma::vec y = vectorise(Y.t());
  arma::mat Z = X.cols(0,n-1);
  arma::mat ZZ_t = Z*Z.t();
  arma::mat Id = eye(d,d);
  
  /* Set convergence criterion */
  int converged = 0;
  int itNum = 0;
  double eps_det = 1e-8;
  
  arma::vec lowerBoundIter = zeros(maxIter+1);
  arma::vec VecOld = join_vert(join_vert(mu_q_nu,vectorise(Mu_q_phi)),
                               vectorise(Mu_q_beta));
  
  /* Start Updating */
  while(converged == 0) {
    /* Update iteration and initialize ELBO (with only constants) */
    itNum = itNum + 1;
    double lowerBound = d*(-0.5*n*log(2*datum::pi) +a_nu*log(b_nu) -lgamma(a_nu)) +
      +0.5*d*(d-1)*0.5*(1-log(tau)) +0.5*d*d_*(1-log(ups));
      
      /* Update NU_1 */
      arma::rowvec Q = Y.row(0) - Mu_q_phi.row(0)*Z;
      arma::mat W = Q*Q.t() + trace(ZZ_t*Sigma_q_phi.slice(0));
      b_q_nu(0) = b_nu + W(0,0)/2;
      mu_q_nu(0) = a_q_nu(0)/b_q_nu(0);
      /* Update ELBO */
      lowerBound = lowerBound - (a_q_nu(0)*log(b_q_nu(0))-lgamma(a_q_nu(0)));
      
      /* Update J-th regression */
      for (int j = 1; j < d; j++) {
        
        /* Get matrix K and vector k */
        arma::mat K_phi = zeros(j,j);
        for (int i = 0; i < j; i++) {
          K_phi(i,i) = trace(Sigma_q_phi.slice(i)*ZZ_t);
        }
        
        /* Update BETA_j */
        arma::mat Q = Y.rows(0,j-1) - Mu_q_phi.rows(0,j-1)*Z;
        arma::mat Sigma_beta_w = inv_sympd(mu_q_nu(j)*(Q*Q.t() + K_phi) + 1/tau*eye(j,j));
        Sigma_q_beta.slice(j).submat(0,0,j-1,j-1) = Sigma_beta_w;
        arma::vec mu_beta_w = Sigma_beta_w*(mu_q_nu(j)*(Q*(Y.row(j)-Mu_q_phi.row(j)*Z).t()));
        Mu_q_beta.submat(j,0,j,j-1) = mu_beta_w.t();
        arma::vec mu_q_betasq = Sigma_beta_w.diag() + pow(mu_beta_w,2);
        /* Update ELBO */
        lowerBound = lowerBound + 0.5*(log(det(Sigma_beta_w)+eps_det)-sum(mu_q_betasq)/tau);
        
        /* Update NU_j */
        arma::rowvec Yj = Y.row(j);
        arma::mat Sigma_phi_j = Sigma_q_phi.slice(j);
        arma::rowvec S = Yj - mu_beta_w.t()*Q - Mu_q_phi.row(j)*Z;
        arma::mat W = S*S.t() + trace(ZZ_t*Sigma_phi_j) + mu_beta_w.t()*K_phi*mu_beta_w + trace(Sigma_beta_w*Q*Q.t()) + 
          trace(Sigma_beta_w*K_phi);
        b_q_nu(j) = b_nu + W(0,0)/2;
        mu_q_nu(j) = a_q_nu(j)/b_q_nu(j);
        /* Update ELBO */
        lowerBound = lowerBound - (a_q_nu(j)*log(b_q_nu(j))-lgamma(a_q_nu(j)));
      }
      
      /* Get matrix C */
      arma::mat C = zeros(d,d);
      for (int i0 = 0; i0 < d; i0++) C = C + mu_q_nu(i0)*Sigma_q_beta.slice(i0);
      arma::mat Mu_omega = (Id - Mu_q_beta).t()*diagmat(mu_q_nu)*(Id - Mu_q_beta);
      Omega_hat = Mu_omega + C;
      
      arma::vec Mu = kron(Omega_hat,Z)*y;
      
      /* Update PHI_j */
      for (int j = 0; j < d; j++) {
        Sigma_q_phi.slice(j) = inv_sympd(Omega_hat(j,j)*ZZ_t + 1/ups*eye(d_,d_));
        
        arma::rowvec Om_jbarj = Omega_hat.row(j);
        Om_jbarj.shed_col(j);
        
        arma::mat Mu_phi_w = Mu_q_phi;
        Mu_phi_w.shed_row(j);
        arma::vec mu_phi_jbar = vectorise(Mu_phi_w.t());
        
        arma::vec Mu_j = Mu.subvec(j*d_,j*d_+d_-1);
        
        arma::vec mu_q_phi_j = Sigma_q_phi.slice(j)*(Mu_j-kron(Om_jbarj,ZZ_t)*mu_phi_jbar);
        Mu_q_phi.row(j) = mu_q_phi_j.t();
        arma::vec mu_q_phisq = Sigma_q_phi.slice(j).diag() + pow(mu_q_phi_j,2);
        /* Update ELBO */
        lowerBound = lowerBound + 0.5*(log(det(Sigma_q_phi.slice(j))+eps_det)-sum(mu_q_phisq)/ups);
      }
      
      /* Store iteration results */
      lowerBoundIter(itNum) = lowerBound;
      arma::vec VecNew = join_vert(join_vert(mu_q_nu,vectorise(Mu_q_phi)),
                                   vectorise(Mu_q_beta));
      
      /* Check convergence */
      if (itNum > 1) {
        double lowerBoundOld = lowerBoundIter(itNum-2);
        double delta_Par = max(abs((VecNew - VecOld)/VecOld));
        double delta_Elbo = abs(lowerBound - lowerBoundOld);
        
        if (delta_Par < Tol_Par)  if (delta_Elbo < Tol_ELBO) converged = 1;
        if (Trace == 1) {
          cout << "Iteration number:" << itNum << "; Parameter R.E:" << delta_Par << "| ELBO R.I:" << delta_Elbo << endl;
        }
      }
      
      if (itNum == maxIter) converged = 1;
      VecOld = VecNew;
  }
  
  /* Return results */
  out["Omega_hat"] = Omega_hat;
  
  out["a_q_nu"] = a_q_nu;
  out["b_q_nu"] = b_q_nu;
  out["mu_q_nu"] = mu_q_nu;
  
  out["Mu_q_beta"] = Mu_q_beta;
  out["Sigma_q_beta"] = Sigma_q_beta;
  
  out["Mu_q_theta"] = Mu_q_phi;
  out["Sigma_q_theta"] = Sigma_q_phi;
  
  out["lowerBoundIter"] = lowerBoundIter.subvec(1,itNum);
  out["lowerBound"] = lowerBoundIter(itNum);
  out["convergence"] = converged;
  
  return out;
}

