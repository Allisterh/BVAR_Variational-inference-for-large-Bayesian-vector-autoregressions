// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(RcppNumerical)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <math.h>  
#include <RcppNumerical.h>
#include <cmath>
#include <iostream>
#include <boost/math/common_factor.hpp> 
#include <boost/math/special_functions/bessel.hpp>
#include <boost/math/special_functions/digamma.hpp>

using namespace Numer;
using namespace std;
using namespace arma;
using namespace Rcpp;

// [[Rcpp::depends(BH)]]

/* Define Log-Bessel function */
double f_logbess(double nu, double a)
{
  double res;
  res = boost::math::cyl_bessel_k(nu,a);
  return log(res);
}

/* Define a function to compute the gradient of
 * the Log-Bessel */
double grad_cpp(double nu0, double a0) {
  
  Rcpp::Environment pkg = Rcpp::Environment::namespace_env("numDeriv");
  Rcpp::Function grad = pkg["grad"];
  
  Rcpp::List results = grad(Rcpp::InternalFunction(f_logbess), 
                            Rcpp::_["x"] = nu0,
                            Rcpp::_["a"] = a0);
  
  return results[0];
}

/* Define the optimal density of Eta and Xi */
class myfun_cost: public Func
{
private:
  double d;
  double taulam;
  double logtau;
  double loglam;
  double e3;
public:
  myfun_cost(double d_, double taulam_, double logtau_, double loglam_, double e3_) : 
  d(d_), taulam(taulam_), logtau(logtau_), loglam(loglam_), e3(e3_) {}
  
  double operator()(const double& x) const
  {
    return exp(d*x*log(x)-d*lgamma(x)-x*(0.5*taulam+e3-logtau-loglam+d*log(2)));
  }
};

class myfun_mu: public Func
{
private:
  double k;
  double d;
  double taulam;
  double logtau;
  double loglam;
  double e3;
public:
  myfun_mu(double k_, double d_, double taulam_, double logtau_, double loglam_, double e3_) : 
  k(k_), d(d_), taulam(taulam_), logtau(logtau_), loglam(loglam_), e3(e3_) {}
  
  double operator()(const double& x) const
  {
    return x*exp(-log(k)+d*x*log(x)-d*lgamma(x)-x*(0.5*taulam+e3-logtau-loglam+d*log(2)));
  }
};


/* Define a function to obtain normalizing constant and
 * expectation of Eta and Xi optimal */
Rcpp::List integrate_latent_factor(const double d, const double taulam, const double logtau, const double loglam, const double e3)
{
  const double lower = 0, upper = 10;
  
  myfun_cost f_tilde(d, taulam, logtau, loglam, e3);
  double err_est;
  int err_code;
  const double res_cost = integrate(f_tilde, lower, upper, err_est, err_code);
  
  myfun_mu f(res_cost, d, taulam, logtau, loglam, e3);
  const double res = integrate(f, lower, upper, err_est, err_code);
  
  return Rcpp::List::create(
    Rcpp::Named("value") = res,
    Rcpp::Named("const_int") = res_cost,
    Rcpp::Named("error_estimate") = err_est,
    Rcpp::Named("error_code") = err_code
  );
}


// [[Rcpp::export]]
Rcpp::List fVBmlrNG(arma::mat D, 
                    arma::mat X, 
                    Rcpp::List hyper,
                  int maxIter = 500, 
                  double Tol_ELBO = 1e-2, 
                  double Tol_Par = 1e-2, 
                  int Trace = 0) {
  
  Rcpp::List out;
  /* Get dimensions */
  double d = D.n_rows;
  double n = D.n_cols-1;
  double d_ = X.n_rows;
  
    /* Get Hyperparameters */
    double a_nu = hyper["a_nu"]; 
    double b_nu = hyper["b_nu"]; 
    
    double e1 = hyper["e1"];    
    double e2 = hyper["e2"]; 
    double e3 = hyper["e3"];  
    
    double h1 = hyper["h1"];     
    double h2 = hyper["h2"]; 
    double h3 = hyper["h3"]; 
    
    /* Initialize optimal quantities */
    arma::cube Sigma_q_phi = zeros(d_,d_,d);
    for (int i = 0; i < d; i++) {
      Sigma_q_phi.slice(i) = eye(d_,d_);
    }
    arma::mat Mu_q_phi = zeros(d,d_);
    
    arma::mat Mu_q_beta = zeros(d,d);
    arma::cube Sigma_q_beta = zeros(d,d,d);
    arma::mat Omega_hat = eye(d,d);
    
    arma::vec mu_q_nu = ones(d);
    arma::vec a_q_nu = (n/2+a_nu)*ones(d);
    arma::vec b_q_nu = ones(d);
    
    arma::mat Mu_q_tau = 0.1*trimatl(ones(d,d));
    Mu_q_tau.diag() = zeros(d);
    arma::mat Mu_q_recip_tau = 1/Mu_q_tau;
    arma::mat Mu_q_logtau = log(Mu_q_tau);
    
    arma::mat Mu_q_lam = trimatl(ones(d,d));
    Mu_q_lam.diag() = zeros(d);    
    arma::mat Mu_q_loglam = Mu_q_lam;
    
    arma::vec mu_q_eta = 0.8*ones(d);

    arma::mat Mu_q_ups = 0.1*ones(d,d_);
    arma::mat Mu_q_recip_ups = Mu_q_ups;
    arma::mat Mu_q_logups = log(Mu_q_ups);
    
    arma::mat Mu_q_kappa = ones(d,d_);
    arma::mat Mu_q_logkappa = ones(d,d_);
    
    arma::vec mu_q_xi = 0.8*ones(d);
    
    /* Define useful quantities */
    arma::mat Y = D.cols(1,n);
    arma::vec y = vectorise(Y.t());
    arma::mat Z = X.cols(0,n-1);
    arma::mat ZZ_t = Z*Z.t();
    arma::mat Id = eye(d,d);
    
    /* Convergence parameters */
    int converged = 0;
    int itNum = 0;
    double eps_det = 1e-8;
    
    arma::vec VecOld = join_vert(join_vert(mu_q_nu,vectorise(Mu_q_phi)),
                                 vectorise(Mu_q_beta));
    arma::vec lowerBoundIter = ones(maxIter+1);
    
    /* Start Updating */
    while(converged == 0) {
      /* Update iteration and initialize ELBO (with only constants) */
      itNum = itNum + 1;
      double lowerBound = d*(-0.5*n*log(2*datum::pi) +a_nu*log(b_nu) -lgamma(a_nu)) +
        0.5*d*(d-1)*0.5 +0.5*d*d +
        0.5*d*(d-1)*(e1*log(e2) - lgamma(e1) + log(e3)) +
        d*d*(h1*log(h2) - lgamma(h1) + log(h3));
      
      arma::mat Yj = Y.row(0);
      /* Update NU_1 */
      arma::rowvec Q = Yj - Mu_q_phi.row(0)*Z;
      arma::mat W = Q*Q.t() + trace(ZZ_t*Sigma_q_phi.slice(0));
      b_q_nu(0) = b_nu + W(0,0)/2;
      mu_q_nu(0) = a_q_nu(0)/b_q_nu(0);
      /* Update ELBO */
      lowerBound = lowerBound - (a_q_nu(0)*log(b_q_nu(0))-lgamma(a_q_nu(0)));

      /* Update J-th regression */
      for (int j = 1; j < d; j++) {
        
        /* Get matrix K and vector k */
        arma::mat K_phi = zeros(j,j);
        for (int i = 0; i < j; i++) {
          K_phi(i,i) = trace(Sigma_q_phi.slice(i)*ZZ_t);
        }
        
        /* Update BETA_j */
        arma::mat Q = Y.rows(0,j-1) - Mu_q_phi.rows(0,j-1)*Z;
        arma::mat Sigma_beta_w = inv_sympd(mu_q_nu(j)*(Q*Q.t() + K_phi) + 
          diagmat(Mu_q_recip_tau.submat(j,0,j,j-1)));
        Sigma_q_beta.slice(j).submat(0,0,j-1,j-1) = Sigma_beta_w;
        arma::vec mu_beta_w = Sigma_beta_w*(mu_q_nu(j)*(Q*(Y.row(j) - Mu_q_phi.row(j)*Z).t()));
        Mu_q_beta.submat(j,0,j,j-1) = mu_beta_w.t();
        arma::vec mu_q_betasq = Sigma_beta_w.diag() + pow(mu_beta_w,2);
        /* Update ELBO */
        lowerBound = lowerBound + 0.5*log(det(Sigma_beta_w)+eps_det);
        
        arma::mat Yj = Y.row(j);
        /* Update NU_j */
        arma::mat Sigma_phi_j = Sigma_q_phi.slice(j);
        arma::rowvec S = Yj - mu_beta_w.t()*Q - Mu_q_phi.row(j)*Z;
        arma::mat W = S*S.t() + trace(ZZ_t*Sigma_phi_j) + mu_beta_w.t()*K_phi*mu_beta_w + trace(Sigma_beta_w*Q*Q.t()) + 
          trace(Sigma_beta_w*K_phi);
        b_q_nu(j) = b_nu + W(0,0)/2;
        mu_q_nu(j) = a_q_nu(j)/b_q_nu(j);
        /* Update ELBO */
        lowerBound = lowerBound - (a_q_nu(j)*log(b_q_nu(j))-lgamma(a_q_nu(j)));
        
        /* Update TAU_j */
        double zeta_q_tau = mu_q_eta(j)-0.5;
        arma::rowvec a_q_tau = mu_q_eta(j)*Mu_q_lam.row(j)+1e-4;
        arma::vec b_q_tau = mu_q_betasq;

        for (int k = 0; k < j; k++) { 
          Mu_q_tau(j,k) = sqrt(b_q_tau(k)/a_q_tau(k)) *
            boost::math::cyl_bessel_k(zeta_q_tau+1.0, sqrt(a_q_tau(k)*b_q_tau(k))) /
              boost::math::cyl_bessel_k(zeta_q_tau, sqrt(a_q_tau(k)*b_q_tau(k)));
          Mu_q_recip_tau(j,k) = sqrt(a_q_tau(k)/b_q_tau(k)) * 
            boost::math::cyl_bessel_k(zeta_q_tau+1.0, sqrt(a_q_tau(k)*b_q_tau(k))) /
              boost::math::cyl_bessel_k(zeta_q_tau, sqrt(a_q_tau(k)*b_q_tau(k))) - 
                2*zeta_q_tau/b_q_tau(k);
          Mu_q_logtau(j,k) = log(sqrt(b_q_tau(k)/a_q_tau(k))) + grad_cpp(zeta_q_tau, sqrt(a_q_tau(k)*b_q_tau(k)));
          
          /* Update ELBO */
          lowerBound = lowerBound - zeta_q_tau/2*log(a_q_tau(k)/b_q_tau(k)) + 
          log(2*boost::math::cyl_bessel_k(zeta_q_tau, sqrt(a_q_tau(k)*b_q_tau(k))));
          
          /* Update LAM_j */
          Mu_q_lam(j,k) = (mu_q_eta(j) + e1)/(0.5*mu_q_eta(j)*Mu_q_tau(j,k) + e2);
          Mu_q_loglam(j,k) = -log(0.5*mu_q_eta(j)*Mu_q_tau(j,k) + e2) + boost::math::digamma(mu_q_eta(j) + e1);
          /* Update ELBO */
          lowerBound = lowerBound - (mu_q_eta(j) + e1)*log(0.5*mu_q_eta(j)*Mu_q_tau(j,k) + e2) +lgamma(mu_q_eta(j) + e1);
        }
          
          /* Update ETA_j */
          Rcpp::List out_eta = integrate_latent_factor(j,
                                                       sum(Mu_q_tau(j,span(0,j-1))%Mu_q_lam(j,span(0,j-1))),
                                                       sum(Mu_q_logtau(j,span(0,j-1))),
                                                       sum(Mu_q_loglam(j,span(0,j-1))),e3);
          mu_q_eta(j) = out_eta["value"];
          double c_eta = out_eta["const_int"];
          /* Update ELBO */
          lowerBound = lowerBound +log(c_eta) +mu_q_eta(j)*sum(Mu_q_lam(j,span(0,j-1))%Mu_q_tau(j,span(0,j-1))-(Mu_q_loglam(j,span(0,j-1))+Mu_q_logtau(j,span(0,j-1))));
        
      }
      
      /* Get matrix C */
      arma::mat C = zeros(d,d);
      for (int i0 = 0; i0 < d; i0++) C = C + mu_q_nu(i0)*Sigma_q_beta.slice(i0);
      arma::mat Mu_omega = (Id - Mu_q_beta).t()*diagmat(mu_q_nu)*(Id - Mu_q_beta);
      Omega_hat = Mu_omega + C;
      
      arma::vec Mu = kron(Omega_hat,Z)*y;
      
      /* Update PHI_j */
      for (int j = 0; j < d; j++) {
        Sigma_q_phi.slice(j) = inv_sympd(Omega_hat(j,j)*ZZ_t + diagmat(Mu_q_recip_ups.row(j)));
        
        arma::rowvec Om_jbarj = Omega_hat.row(j);
        Om_jbarj.shed_col(j);
        
        arma::mat Mu_phi_w = Mu_q_phi;
        Mu_phi_w.shed_row(j);
        arma::vec mu_phi_jbar = vectorise(Mu_phi_w.t());
        
        arma::vec Mu_j = Mu.subvec(j*d_,j*d_+d_-1);
        
        arma::vec mu_q_phi_j = Sigma_q_phi.slice(j)*(Mu_j-kron(Om_jbarj,ZZ_t)*mu_phi_jbar);
        Mu_q_phi.row(j) = mu_q_phi_j.t();
        arma::vec mu_q_phisq = Sigma_q_phi.slice(j).diag() + pow(mu_q_phi_j,2);
        /* Update ELBO */
        lowerBound = lowerBound + 0.5*log(det(Sigma_q_phi.slice(j))+eps_det);
        
        /* Update UPS */
        double zeta_q_ups = mu_q_xi(j) - 0.5;
        arma::rowvec a_q_ups = mu_q_xi(j)*Mu_q_kappa.row(j)+1e-4;
        arma::vec b_q_ups = mu_q_phisq;
        
        for (int j0 = 0; j0 < d_; j0++) {
          Mu_q_ups(j,j0) = sqrt(b_q_ups(j0)/a_q_ups(j0)) *
            boost::math::cyl_bessel_k(zeta_q_ups+1, sqrt(a_q_ups(j0)*b_q_ups(j0))) /
              boost::math::cyl_bessel_k(zeta_q_ups, sqrt(a_q_ups(j0)*b_q_ups(j0)));
          Mu_q_recip_ups(j,j0) = sqrt(a_q_ups(j0)/b_q_ups(j0)) * 
            boost::math::cyl_bessel_k(zeta_q_ups+1, sqrt(a_q_ups(j0)*b_q_ups(j0))) /
              boost::math::cyl_bessel_k(zeta_q_ups, sqrt(a_q_ups(j0)*b_q_ups(j0))) - 
                2*zeta_q_ups/b_q_ups(j0);
          Mu_q_logups(j,j0) = log(sqrt(b_q_ups(j0)/a_q_ups(j0))) + grad_cpp(zeta_q_ups, sqrt(a_q_ups(j0)*b_q_ups(j0)));
          
          /* Update ELBO */
          lowerBound = lowerBound - zeta_q_ups/2*log(a_q_ups(j0)/b_q_ups(j0)) +
          log(2*boost::math::cyl_bessel_k(zeta_q_ups, sqrt(a_q_ups(j0)*b_q_ups(j0))));
          
          /* Update KAPPA */
          double a_q_kappa = mu_q_xi(j) + h1;
          double b_q_kappa = 0.5*mu_q_xi(j)*Mu_q_ups(j,j0) + h2;
          
          Mu_q_kappa(j,j0) = a_q_kappa/b_q_kappa;
          Mu_q_logkappa(j,j0) = -log(b_q_kappa) + boost::math::digamma(a_q_kappa);
          
          /* Update ELBO */
          lowerBound = lowerBound + (-a_q_kappa*log(b_q_kappa) + lgamma(a_q_kappa)); 
        }
        
        /* Update XI */
        Rcpp::List out_xi = integrate_latent_factor(d_,sum(Mu_q_ups.row(j)%Mu_q_kappa.row(j)),
                                                    sum(Mu_q_logups.row(j)),sum(Mu_q_logkappa.row(j)),h3);
        mu_q_xi(j) = out_xi["value"];
        double c_xi = out_xi["const_int"];
        
        /* Update ELBO */
        lowerBound = lowerBound + log(c_xi) +
        mu_q_xi(j)*(sum(Mu_q_ups.row(j)%Mu_q_kappa.row(j)) - (sum(Mu_q_logups.row(j))+sum(Mu_q_logkappa.row(j)))); 
      }
      
      /* Store iteration results */
      lowerBoundIter(itNum) = lowerBound;
      arma::vec VecNew = join_vert(join_vert(mu_q_nu,vectorise(Mu_q_phi)),
                                   vectorise(Mu_q_beta));
      
      /* Check convergence */
      if (itNum > 1) {
        double lowerBoundOld = lowerBoundIter(itNum-2);
        double delta_Par = max(abs((VecNew - VecOld)/VecOld));
        double delta_Elbo = abs((lowerBound - lowerBoundOld)/lowerBoundOld);
        
        if (delta_Par < Tol_Par)  if (delta_Elbo < Tol_ELBO) converged = 1;
        if (Trace == 1) {
          cout << "Iteration number:" << itNum << "; Parameter R.E:" << delta_Par << "| ELBO R.I:" << delta_Elbo << endl;
        }
      }
      
      if (itNum == maxIter) converged = 1;
      VecOld = VecNew;
    }
    
    /* Return results */
    out["Omega_hat"] = Omega_hat;
    
    out["a_q_nu"] = a_q_nu;
    out["b_q_nu"] = b_q_nu;
    out["mu_q_nu"] = mu_q_nu;
    
    out["Mu_q_beta"] = Mu_q_beta;
    out["Sigma_q_beta"] = Sigma_q_beta;
    
    out["Mu_q_theta"] = Mu_q_phi;
    out["Sigma_q_theta"] = Sigma_q_phi;
    
    out["lowerBoundIter"] = lowerBoundIter.subvec(1,itNum);
    out["lowerBound"] = lowerBoundIter(itNum);
    out["convergence"] = converged;
  
  return out;
}



