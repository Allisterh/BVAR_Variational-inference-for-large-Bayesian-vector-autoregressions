VBmlr = function(Y,X=NULL,AR=TRUE,
                 hyper = list(a_nu = 0.1,
                              b_nu = 0.1,
                              tau = 1,
                              ups = 1),
                 prior = "normal",
                 maxIter = 500, 
                 Tol_ELBO = 1e-2, 
                 Tol_Par = 1e-2, 
                 Trace = 0) {
  
  n = ncol(Y)
  if (!is.null(X)) Z = rbind(matrix(1,1,n),X)
  if (is.null(X)) Z = matrix(1,1,n)
  X = Z
  if (AR==TRUE) X = rbind(Y,X)
  
  if (prior == "normal") {
    out = fVBmlr(Y,X,
                 hyper,
                 maxIter = maxIter,
                 Tol_ELBO = Tol_ELBO, 
                 Tol_Par = Tol_Par, 
                 Trace = Trace)
  }
  
  if (prior == "lasso") {
    out = fVBmlrL(Y,X,
                 hyper,
                 maxIter = maxIter,
                 Tol_ELBO = Tol_ELBO, 
                 Tol_Par = Tol_Par, 
                 Trace = Trace)
  }
  
  if (prior == "ng") {
    out = fVBmlrNG(Y,X,
                 hyper,
                 maxIter = maxIter,
                 Tol_ELBO = Tol_ELBO, 
                 Tol_Par = Tol_Par, 
                 Trace = Trace)
  }
  
  if (prior == "hs") {
    out = fVBmlrHS(Y,X,
                 hyper,
                 maxIter = maxIter,
                 Tol_ELBO = Tol_ELBO, 
                 Tol_Par = Tol_Par, 
                 Trace = Trace)
  }
  
  
  out
}
