#: Plot the optimal densities (beta, theta, nu)
qDensity = function(mod, param, index) {
  require(ggplot2)
  require(TeachingDemos)
  
  j = index[1]
  k = index[2]
  jk = paste(j,",",k,sep="")
  
  d = nrow(mod$Mu_q_theta)
  d_ = ncol(mod$Mu_q_theta)

  if (param == 'beta') {
    if ((j > 1)&(j < (d+1))&(k < j)) {
      HPD = hpd(function(x) qnorm(x, mod$Mu_q_beta[j,k], sqrt(mod$Sigma_q_beta[k,k,j])))
      fHPD = dnorm(HPD[1], mod$Mu_q_beta[j,k], sqrt(mod$Sigma_q_beta[k,k,j]))
      
      p = ggplot() + 
        geom_segment(aes(x=HPD[1],xend=HPD[1],y=0,yend=fHPD),size=1.2,col="red",alpha=0.5) +
        geom_segment(aes(x=HPD[2],xend=HPD[2],y=0,yend=fHPD),size=1.2,col="red",alpha=0.5) +
        stat_function(fun = function(x) dnorm(x, mod$Mu_q_beta[j,k], sqrt(mod$Sigma_q_beta[k,k,j])),
                                   size = 1.2) + theme_minimal() +
        scale_x_continuous(breaks=HPD,limits=c(mod$Mu_q_beta[j,k]-4*sqrt(mod$Sigma_q_beta[k,k,j]), mod$Mu_q_beta[j,k]+4*sqrt(mod$Sigma_q_beta[k,k,j]))) +
        ggtitle(bquote(paste(paste(mu," = ",.(round(mod$Mu_q_beta[j,k],3)),sep=""),
                             paste("   and   "),
                             paste(sigma," = ",.(round(sqrt(mod$Sigma_q_beta[k,k,j]),3)),sep="")))) +
        xlab(bquote(beta[.(jk)])) + ylab("") +
        theme(plot.title = element_text(hjust = 0.5),
              text = element_text(size=15), 
              axis.title.x = element_text(size=20))
      
    } else {
      print("Wrong Indexes provided")
    }
  }
  
  if (param == 'theta') {
    if ((j > 0)&(j < (d+1))&(k > 0)&(k < d_+1)) {
      HPD = hpd(function(x) qnorm(x, mod$Mu_q_theta[j,k], sqrt(mod$Sigma_q_theta[k,k,j])))
      fHPD = dnorm(HPD[1], mod$Mu_q_theta[j,k], sqrt(mod$Sigma_q_theta[k,k,j]))
      
      Stdev = sqrt(mod$Sigma_q_theta[k,k,j])
      p = ggplot() + geom_segment(aes(x=HPD[1],xend=HPD[1],y=0,yend=fHPD),size=1.2,col="red",alpha=0.5) +
        geom_segment(aes(x=HPD[2],xend=HPD[2],y=0,yend=fHPD),size=1.2,col="red",alpha=0.5) +
        stat_function(fun = function(x) dnorm(x, mod$Mu_q_theta[j,k], Stdev),
                                   size = 1.2) + theme_minimal() +
        scale_x_continuous(breaks=HPD,limits=c(mod$Mu_q_theta[j,k]-4*Stdev, mod$Mu_q_theta[j,k]+4*Stdev)) +
        ggtitle(bquote(paste(paste(mu," = ",.(round(mod$Mu_q_theta[j,k],3)),sep=""),
                             paste("   and   "),
                             paste(sigma," = ",.(round(Stdev,3)),sep="")))) +
        xlab(bquote(theta[.(jk)])) + ylab("") +
        theme(plot.title = element_text(hjust = 0.5),
              text = element_text(size=15), 
              axis.title.x = element_text(size=20))
    } else {
      print("Wrong Indexes provided")
    }
  }
  
  if (param == 'nu') {
    if ((j > 0)&(j < (d+1))&(k > 0)&(k < (d+1)&(j == k))) {
      HPD = hpd(function(x) qgamma(x, mod$a_q_nu[j], mod$b_q_nu[j]))
      fHPD = dgamma(HPD[1], mod$a_q_nu[j], mod$b_q_nu[j])
      
      mu = mod$mu_q_nu[j]
      s  = sqrt(mod$a_q_nu[j]/mod$b_q_nu[j]^2)
      p = ggplot() + 
        geom_segment(aes(x=HPD[1],xend=HPD[1],y=0,yend=fHPD),size=1.2,col="red",alpha=0.5) +
        geom_segment(aes(x=HPD[2],xend=HPD[2],y=0,yend=fHPD),size=1.2,col="red",alpha=0.5) +
        stat_function(fun = function(x) dgamma(x, mod$a_q_nu[j], mod$b_q_nu[j]),
                                   size = 1.2) + theme_minimal() +
        scale_x_continuous(breaks=HPD,limits=c(mu-4*s, mu+4*s)) +
        ggtitle(bquote(paste(paste(mu," = ",.(round(mu,3)),sep=""),
                             paste("   and   "),
                             paste(sigma," = ",.(round(s,3)),sep="")))) +
        xlab(bquote(nu[.(as.character(j))])) + ylab("") +
        theme(plot.title = element_text(hjust = 0.5),
              text = element_text(size=15), 
              axis.title.x = element_text(size=20))
    } else {
      print("Wrong Indexes provided")
    }
  }
  
  HPD = round(HPD,4)
  print(paste0("HPD 95% interval: [",HPD[1]," ; ",HPD[2],"]"))
  p
}

#: Sparsity via SAVS
SAVS = function(Phi_hat,Z) {
  Phi_sp = matrix(0,nrow(Phi_hat),ncol(Phi_hat))
  
  Znorm = apply(Z,1,function(x) sum(x^2))
  Mu = 1/abs(Phi_hat)^2
  
  for (j in 1:nrow(Phi_hat)) {
    logicVec = abs(Phi_hat[j,])*Znorm > Mu[j,]
    Phi_sp[j,] = Phi_hat[j,]
    Phi_sp[j,!logicVec] = 0
  }
  
  Phi_sp
}

#: Example matrix
Omega_example = function() {
  
  # Define sparse correlation matrix
  # Wang [2015, Bayesian Analysis]
  mX = matrix(0, 12, 12)
  
  # Variances
  mX[1, 1]   = 0.239;
  mX[2, 2]   = 1.554;
  mX[3, 3]   = 0.362;
  mX[4, 4]   = 0.199;
  mX[5, 5]   = 0.349;
  mX[6, 6]   = 0.295;
  mX[7, 7]   = 0.715;
  mX[8, 8]   = 0.164;
  mX[9, 9]   = 0.518;
  mX[10, 10] = 0.379;
  mX[11, 11] = 0.159;
  mX[12, 12] = 0.207;
  
  # Covariances
  mX[1, 2]   = 0.117; 
  mX[1, 8]   = 0.031;
  mX[2, 1]   = 0.117;
  mX[3, 4]   = 0.002;
  mX[4, 3]   = 0.002;
  mX[4, 5]   = 0.094;  
  mX[5, 4]   = 0.094;
  mX[5, 12]  = -0.036;
  mX[6, 7]   = -0.229;
  mX[6, 8]   = 0.002;
  mX[7, 6]   = -0.229;
  mX[8, 1]   = 0.031;
  mX[8, 6]   = 0.002;
  mX[8, 9]   = 0.112;
  mX[8, 10]  = -0.028;
  mX[8, 11]  = -0.008;
  mX[9, 8]   = 0.112;
  mX[9, 10]  = -0.193;
  mX[9, 11]  = -0.090;
  mX[10, 8]  = -0.028;
  mX[10, 9]  = -0.193;
  mX[10, 11] = 0.167;
  mX[11, 8]  = -0.008;
  mX[11, 9]  = -0.090;
  mX[11, 10] = 0.167;
  mX[12, 5]  = -0.036;
  
  mX
}

Phi_example = function() {
  
  # Define sparse autoregressive matrix
  mX = matrix(0, 12, 12)
  
  # Diagonal
  mX[1, 1]   = 0.239;
  mX[2, 2]   = 0.554;
  mX[3, 3]   = 0.362;
  mX[4, 4]   = 0.199;
  mX[5, 5]   = 0.349;
  mX[6, 6]   = 0.295;
  mX[7, 7]   = 0.715;
  mX[8, 8]   = 0.164;
  mX[9, 9]   = 0.518;
  mX[10, 10] = 0.379;
  mX[11, 11] = 0.159;
  mX[12, 12] = 0.207;
  
  # Off-diagonal
  mX[2, 1]   = 0.117;
  mX[6, 7]   = -0.229;
  mX[8, 9]   = 0.112;
  mX[9, 10]  = -0.193;
  mX[11, 10] = 0.167;

  mX
}

Gamma_example = function() {
  
  # Define sparse regression matrix
  mX = matrix(0, 12, 3)
  
  mX[1, 2]   = 0.239;
  mX[5, 3]   = 0.554;
  mX[6, 2]   = 0.295;
  mX[7, 1]   = 0.715;
  mX[8, 1]   = 0.164;
  mX[11, 3] = 0.159;
  mX[12, 2] = 0.207;
  
  mX
}



#: Plot matrix
matrixplot = function(m1, m2 = NULL) {
  require(ggplot2)
  require(reshape2)
  
  if (is.null(m2)) {
    
    d = nrow(m1)
    p = ncol(m1)
    
    m.mat = melt(t(m1)[,d:1])
    names(m.mat)[3] = "Value"

    if ((!is.null(rownames(m1))) & (!is.null(colnames(m2)))) {
      nx = colnames(m1)
      ny = rownames(m1)[d:1]
    } else {
      nx = 1:p
      ny = d:1
    }
    
    pl = ggplot() + 
      geom_tile(data = m.mat, aes(x=as.numeric(Var1), y=as.numeric(Var2), fill=Value)) + ylab('') + xlab('') +
      scale_fill_gradient2(low = "red", high = "blue", mid="white",
                           midpoint = 0) +
      geom_rect(aes(ymin=0.5,ymax=d+0.5,xmin=0.5,xmax=p+0.5),col="black",fill=NA,linetype='dashed') +
      theme(panel.grid = element_blank(), panel.background = element_rect(fill='white'),
            plot.background = element_rect(color=NA), axis.title.x=element_blank(), axis.title.y=element_blank(),
            axis.text.x = element_text(angle=90, vjust=0.4), text = element_text(size=15),
            legend.position = "right") +
      scale_x_continuous(1:p, breaks=1:p, labels = nx) + 
      scale_y_continuous(1:d, breaks=1:d, labels = ny) 
  }
  
  if (!is.null(m2)) {
    require(ggnewscale)
    d = nrow(m1)
    p1 = ncol(m1)
    p2 = ncol(m2)
    
    m.mat1 = melt(t(m1)[,d:1])
    m.mat2 = melt(t(m2)[,d:1])
    
    names(m.mat1)[3] = "Value1"
    names(m.mat2)[3] = "Value2"
    
    if ((!is.null(rownames(m1))) & 
        (!is.null(colnames(m1))) & 
        (!is.null(colnames(m2)))) {
      nx = c(colnames(m1),colnames(m2))
      ny = rownames(m1)[d:1]
    } else {
      nx = c(1:p1,1:p2)
      ny = d:1
    }
    
    pl = ggplot() + 
      geom_tile(data = m.mat1, aes(x=as.numeric(Var1), y=as.numeric(Var2), fill=Value1)) + ylab('') + xlab('') +
      scale_fill_gradient2(low = "red", high = "blue", mid="white",
                           midpoint = 0) +
      new_scale_fill() +
      geom_tile(data = m.mat2, aes(x=as.numeric(Var1)+p1+1, y=as.numeric(Var2), fill=Value2)) + ylab('') + xlab('') +
      scale_fill_gradient2(low = "red", high = "blue", mid="white",
                           midpoint = 0) +
      geom_rect(aes(ymin=0.5,ymax=d+0.5,xmin=0.5,xmax=p1+0.5),col="black",fill=NA,linetype='dashed') +
      geom_rect(aes(ymin=0.5,ymax=d+0.5,xmin=p1+1.5,xmax=p1+p2+1+0.5),col="black",fill=NA,linetype='dashed') +
      scale_x_continuous(1:(p1+p2+1), breaks=(1:(p1+p2+1))[-(p1+1)], labels = nx) + 
      scale_y_continuous(1:d, breaks=1:d, labels = ny) +
      theme(panel.grid = element_blank(), panel.background = element_rect(fill='white'),
            plot.background = element_rect(color=NA), axis.title.x=element_blank(), axis.title.y=element_blank(),
            axis.text.x = element_text(angle=90, vjust=0.4), text = element_text(size=15),
            legend.position = "right")
  }
  
  plot(pl)
}


#: Density approximation for Omega
qOmega = function(mod) {
  d = nrow(mod$Mu_q_theta)
  
  Om = mod$Omega_hat
  mu_lnu = psigamma(mod$a_q_nu)-log(mod$b_q_nu)
  
  df = uniroot(function(x) d*log(2)-d*log(x)+log(det(Om))+sum(psigamma(1/2*(x+1-seq(1,d))))-sum(mu_lnu), 
               interval=c(d-1+1e-5,1e5))$root
  V = Om/df
  
  list(df=df,V=V)
}

#: Variational predictive posterior
qExactPredictive = function(mod,qOm,z,R=5000) {
  require(mvnfast)
  require(Matrix)
  
  d = nrow(mod$Mu_q_theta)
  d_ = ncol(mod$Mu_q_theta)
  
  Z = kronecker(diag(1,d),t(z))
  
  mu_th = as.vector(mod$Mu_q_theta)
  Sigma_th = as.matrix(bdiag(lapply(seq(dim(mod$Sigma_q_theta)[3]), function(x) mod$Sigma_q_theta[,,x])))
  
  nu = qOm$df-d+1
  S = 1/nu*solve(qOm$V)
  
  Ysim = matrix(NA,d,R)
  for (r in 1:R) {
    Th_sim = t(rmvn(1,mu_th,Sigma_th))
    Ysim[,r] = t(mvnfast::rmvt(1,Z%*%Th_sim,S,nu))
  }
  
  Ysim
}

qApproxPredictive = function(mod,qOm,z) {
  library(Matrix)
  d = nrow(mod$Mu_q_theta)
  d_ = ncol(mod$Mu_q_theta)
  
  Z = kronecker(diag(1,d),t(z))
  
  mu_th = as.vector(mod$Mu_q_theta)
  Sigma_th = bdiag(lapply(seq(dim(mod$Sigma_q_theta)[3]), function(x) mod$Sigma_q_theta[,,x]))
  
  nu = qOm$df-d+1
  S = 1/nu*solve(qOm$V)
  
  R = (nu-2)/nu*solve(S)
  Stilde = solve(solve(Sigma_th)+t(Z)%*%R%*%Z)
  
  Sy = solve(R-R%*%Z%*%Stilde%*%t(Z)%*%R)
  Muy = Sy%*%(R%*%Z%*%Stilde%*%solve(Sigma_th)%*%mu_th)
  
  list(mu=as.vector(Muy),
       Sigma=as.matrix(Sy))
}



